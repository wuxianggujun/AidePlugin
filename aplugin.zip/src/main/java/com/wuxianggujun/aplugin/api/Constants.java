package com.wuxianggujun.aplugin.api;

public class Constants {
    public static final String PLUGIN_CLASS_NAME = "plugin_class_name";
    public static final String PACKAGE_NAME = "package_name";
}